package com.example.sharedpreferencesdemo

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var greetingTextView: TextView
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var loadButton: Button
    private lateinit var clearButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        greetingTextView = findViewById(R.id.tv_greeting)
        nameEditText = findViewById(R.id.et_name)
        emailEditText = findViewById(R.id.et_email)
        ageEditText = findViewById(R.id.et_age)
        saveButton = findViewById(R.id.btn_save)
        loadButton = findViewById(R.id.btn_load)
        clearButton = findViewById(R.id.btn_clear)

        // Handle window insets (optional, for edge-to-edge UI)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Set click listeners
        saveButton.setOnClickListener {
            saveData()
        }

        loadButton.setOnClickListener {
            loadData()
        }

        clearButton.setOnClickListener {
            clearData()
        }
    }

    private fun saveData() {
        val name = nameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val age = ageEditText.text.toString().trim()

        // Input validation
        if (name.isEmpty()) {
            nameEditText.error = "Please enter your name"
            return
        }

        if (email.isEmpty()) {
            emailEditText.error = "Please enter your email"
            return
        }

        if (age.isEmpty()) {
            ageEditText.error = "Please enter your age"
            return
        }


        // Save data to SharedPreferences if all fields are filled
        val sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("userName", name)
        editor.putString("userEmail", email)
        editor.putString("userAge", age)
        editor.apply()

        greetingTextView.text = "Data saved!"
    }


    private fun loadData() {
        val sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)

        val savedName = sharedPreferences.getString("userName", "No name saved")
        val savedEmail = sharedPreferences.getString("userEmail", "No email saved")
        val savedAge = sharedPreferences.getString("userAge", "No age saved")

        greetingTextView.text = "Welcome, $savedName! Email: $savedEmail , Age: $savedAge"
    }

    private fun clearData() {
        val sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.clear().apply()  // Clears all data in SharedPreferences

        greetingTextView.text = "Data cleared!"
        nameEditText.text.clear()
        emailEditText.text.clear()
        ageEditText.text.clear()
    }
}