package com.example.fragmentexample

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class Fragment1 : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_first, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set a click listener to send data to Fragment2
        view.findViewById<View>(R.id.button_send_data).setOnClickListener {
            // Send data to Fragment2 via MainActivity
            if (activity is MainActivity) {
                (activity as MainActivity).sendDataToFragment2("Hello from Fragment1")
            }
        }
    }
}
