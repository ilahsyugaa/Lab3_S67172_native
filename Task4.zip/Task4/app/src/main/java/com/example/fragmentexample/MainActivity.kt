package com.example.fragmentexample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // If this is the first time the activity is created, add the fragments
        val fragment1 = Fragment1()
        val fragment2 = Fragment2()

        // Begin transaction to add both fragments
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container1, fragment1)
        transaction.replace(R.id.fragment_container2, fragment2)
        transaction.commit()
    }

    fun sendDataToFragment2(data: String) {
        // Find Fragment2 and update it with the new data
        val fragment2 = supportFragmentManager.findFragmentById(R.id.fragment_container2)
        if (fragment2 is Fragment2) {
            fragment2.updateData(data)
        }
    }
}
